﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using System.Collections;

namespace SQLServer01
{
    public partial class frmMain : Form
    {
        
        /*connection String = "AzureSQl - 설정 - 연결문자열 - ADO.NET(SQL인증) - password 따로 입력할것"*/
        
        private const string CONNECTION_STRING = "";
        private SqlConnection SqlCon = null;
        private SqlCommand SqlCmd = null;
        private SqlDataAdapter SqlApt = new SqlDataAdapter();

        private DataSet dataMain = new DataSet();
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            SqlCon = new SqlConnection(CONNECTION_STRING); /*SQL DB와 연결*/
            btnConnect.Enabled = false; /*연결 후 버튼은 사용할 수 없는 상태가 된다.*/
        }

        private void btnGetData_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM production.brands";
            SqlCommand cmd = SqlCon.CreateCommand();
            cmd.CommandText = query;

            SqlApt.SelectCommand= cmd;
            SqlApt.Fill(dataMain);

            lstBrends.Items.Clear();

            DataRowCollection dataRows = dataMain.Tables[0].Rows;

            for(int i = 0; i< dataRows.Count; i++) 
            {
                lstBrends.Items.Add(dataRows[i][1].ToString());
            }


            btnGetData.Enabled = false;
        }

        private void lstBrends_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstBrends.SelectedIndex == -1)
            {
                return;
            }


            //File to DataGridView
            int selectedIndex = lstBrends.SelectedIndex;
            int selectedBrandId = Int32.Parse(dataMain.Tables[0].Rows[selectedIndex][0].ToString()); // [0]은 BrandID를 의미, [1]은 Brandname을 의미


            DataSet dataProducts = new DataSet();
            string query = "SELECT * FROM production.products WHERE brand_id = @brand_id";
            SqlCommand cmd = SqlCon.CreateCommand();
            cmd.Parameters.Add(new SqlParameter("@brand_id", SqlDbType.Int)).Value = selectedBrandId;
            cmd.CommandText = query;
            SqlApt.SelectCommand= cmd;
            SqlApt.Fill(dataProducts);
            grdProducts.DataSource = dataProducts.Tables[0];
        }

        private void btnVIPmembers_Click(object sender, EventArgs e)
        {
            frmVIPMembers vip = new frmVIPMembers();
            vip.ShowDialog();
        }
    }
}

// ADO>NET 구조 : dataset - tables - row 형태로 이루어져있다.