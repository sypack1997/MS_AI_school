﻿namespace SQLServer01
{
    partial class frmVIPMembers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grdMemberlist = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btlClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdMemberlist)).BeginInit();
            this.SuspendLayout();
            // 
            // grdMemberlist
            // 
            this.grdMemberlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdMemberlist.Location = new System.Drawing.Point(508, 114);
            this.grdMemberlist.Name = "grdMemberlist";
            this.grdMemberlist.RowHeadersWidth = 51;
            this.grdMemberlist.RowTemplate.Height = 24;
            this.grdMemberlist.Size = new System.Drawing.Size(240, 150);
            this.grdMemberlist.TabIndex = 0;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(190, 47);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 1;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // btlClose
            // 
            this.btlClose.Location = new System.Drawing.Point(179, 215);
            this.btlClose.Name = "btlClose";
            this.btlClose.Size = new System.Drawing.Size(75, 23);
            this.btlClose.TabIndex = 2;
            this.btlClose.Text = "Close";
            this.btlClose.UseVisualStyleBackColor = true;
            this.btlClose.Click += new System.EventHandler(this.btlClose_Click);
            // 
            // frmVIPMembers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btlClose);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.grdMemberlist);
            this.Name = "frmVIPMembers";
            this.Text = "frmVIPMembers";
            this.Load += new System.EventHandler(this.frmVIPMembers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdMemberlist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView grdMemberlist;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btlClose;
    }
}