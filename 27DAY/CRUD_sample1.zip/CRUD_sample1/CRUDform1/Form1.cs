﻿using System.Data;
using System.Data.SqlClient;

namespace CRUDform1
{
    public partial class frmMain : Form
    {

        /// <summary>
        /// connection String = "AzureSQl - 설정 - 연결문자열 - ADO.NET(SQL인증) - password 따로 입력할것"
        /// </summary>
        
        private const string ConnectionString = "Server=tcp:azuresql45.database.windows.net,1433;Initial Catalog=AzureSQL;Persist Security Info=False;User ID=sypack1997;Password=tkdduf1997!!;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        private SqlConnection
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_btnConnect_click(object sender, EventArgs e)
        {

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {

        }
    }
}